# NOVI LIST
# Croatia
import requests
from lxml import html
import sqlite3
conn = sqlite3.connect(sys.argv[1])
c = conn.cursor()
url = sys.argv[2]
page = int(sys.argv[3])

while True:
	print('Started processing page: ' + str(page))
	r = requests.get(url + str(site))
	p = html.fromstring(r.text)
	t = p.xpath('//div/a/@href')
	#print(t)
	for l in t:
		a = Article(l)
		a.download()
		a.parse()
		# default variables: a.title, a.publish_date, a.authors, a.text
		# if some don't work, mine for them in code
		# START: mine for date, authors
		r2 = requests.get(url2 + l)
		p2 = html.fromstring(r2.text)
		date = p2.xpath('//span[@itemprop="datePublished"]/text()')
		if len(date) > 0:
			date = date[0]
			date = date.split('T')
			date = date[0]
		else:	
			date = ''
		author = p2.xpath('//span[@itemprop="author"]/text()')
		if len(author) > 0:
			author = author[0]
		else:
			author = ''
		q1 = c.execute('select count(*) from articles where title = ?;', [title])
		r1 = q1.fetchone()
		exists = r1[0]
		if exists == 0:
			q2 = c.execute('insert into articles values(Null, ?, ?, ?, ?, ?, ?);', [a.title, date, author, a.text, l, date.today().strftime('%Y-%m-%d')])
			conn.commit()
	print('Successfully processed page: ', site)
	page = page - 1
