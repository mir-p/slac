# GAZETA KRAKOWSKA
# Poland
import requests
from lxml import html
from newspaper import Article
import sys
import sqlite3
from datetime import date
conn = sqlite3.connect(sys.argv[1])
c = conn.cursor()
url = sys.argv[2]
page = int(sys.argv[3])

while True:
	print('Started processing page: ' + str(page))
	r = requests.get(url + str(page))
	p = html.fromstring(r.text)
	# START: mine for links
	# on every column page with links to articles mine for the very links (xpath code of a link)
	t = p.xpath('//article/a/@href')
	# STOP: mine for links
	for l in t:
		a = Article(l)
		a.download()
		a.parse()
		if a.publish_date == None:
			continue
		# default variables: a.title, a.publish_date, a.authors, a.text
		# if some don't work, mine for them in code
		# START: mine for text
		r1 = requests.get(l)
		p1 = html.fromstring(r.text)
		text = p1.xpath('//div[@class="md"]//text()')
		if len(text) > 0:
			text = ' '.join(text)
		else:
			text = ''
		# STOP: mine for text
		q1 = c.execute('select count(*) from articles where title = ?;', [a.title])
		if q1.fetchone()[0] == 0:
			q2 = c.execute('insert into articles values(Null, ?, ?, ?, ?, ?, ?);', [a.title, a.publish_date.strftime('%Y-%m-%d'), ', '.join(a.authors), text, l, date.today().strftime('%Y-%m-%d')])
			conn.commit()
	print('Successfully processed page: ' + str(page))
	page = page + 1
