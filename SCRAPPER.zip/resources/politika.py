# POLITIKA
# Serbia
import requests
from lxml import html
import sqlite3
import datetime
import time
import sys
from transliterate import translit, get_available_language_codes
conn = sqlite3.connect(sys.argv[1])
c = conn.cursor()
url1 = sys.argv[2]

# IMPORTANT SETTINGS - CHANGE ACCORDINGLY! [START]
startDate = '2018-01-01'
stopDate = '2019-10-01'
cols = ['Политика']
# IMPORTANT SETTINGS [STOP]

# auxiliary code - START
url2 = 'http://www.politika.rs'
def safeReq(url):
	for i in range(0,10):
		while True:
			try:
				r = requests.get(url)
				return r.text
			except requests.exceptions.ConnectionError:
				print('waiting 1sec')
				time.sleep(1)
				continue
			break
start = datetime.datetime.strptime(startDate, '%Y-%m-%d')
end = datetime.datetime.strptime(stopDate, '%Y-%m-%d')
step = datetime.timedelta(days=1)
# auxiliary code - STOP

while start <= end:
	url = url1 + start.strftime('%Y/%m/%d')
	p1 = html.fromstring(safeReq(url))
	# START: dive into archive structure
	# on every archive page referring to a particular day mine for subpages (xpath code of links)
	s = p1.xpath('//ul[@class="overflow-hidden sm-show center  arial"]/li')
	# STOP: dive into archive structure
	if len(s) > 0:
		sites = s[-1].xpath('.//text()')
		sites = sites[0]
		for i in range(1, int(sites)+1):
			p = html.fromstring(safeReq(url+'/page:'+str(i)))
			# START: mine for article links
			# on every archive subpage with links to articles mine for the very links (xpath code of a link)
			t = p.xpath('//div[@class="archive-list"]/div')
			colTitle = ''
			links = []
			# check if they belong to the category we are looking for (e.g. Politika, Svet etc.)
			for cl in t:
				column = cl.xpath('./@class')
				if len(column) > 0:
					column = column[0]
				else:
					column = ''
				if column == 'box sm-col sm-col-12 md-col-12 lg-col-12 roboto-slab h3 bold mt2 mb1':
					colTitle = cl.xpath('./text()')
					if len(colTitle) > 0:
						colTitle = colTitle[0]
					else:
						colTitle = ''
				if colTitle in cols:
					lx = cl.xpath('.//a/@href')
					if len(lx) > 0:
						links.append([lx[0], translit(colTitle, 'sr', reversed=True)])

			for link in links:
				# mine for title, date, authors, text in code
				p3 = html.fromstring(safeReq(url2+link[0]))
				title = p3.xpath('//meta[@property="og:title"]/@content')
				if len(title) > 0:
					title = translit(title[0], 'sr', reversed=True)
				else:
					title = ''
				date = p3.xpath('//div[@class="h6 mt1 mb1 arial gray lighter"]/text()')
				if len(date) > 0:
					date = date[-1]
					date = date.split(', ')
					date = date[1]
					date = date.split('. ')
					date = date[0]
					date = datetime.datetime.strptime(date, '%d.%m.%Y').date()
				else:
					date = ''
				author = p3.xpath('//meta[@name="author"]/@content')
				if len(author) > 0:
					author = translit(author[0], 'sr', reversed=True)
				else:
					author = ''
				lead = p3.xpath('//div[@class="h4 mt0 mb2 regular roboto-slab"]//text()')
				if len(lead) > 0:
					lead = lead[0]
				else:
					lead = ''
				text = p3.xpath('//div[@class="article-content mt3 mb3"]//text()')
				text = translit('\n'.join(text), 'sr', reversed=True)
				q1 = c.execute('select count(*) from articles where title = ?;', [title])
				r1 = q1.fetchone()
				exists = r1[0]
				if exists == 0:
					q2 = c.execute('insert into articles values(Null, ?, ?, ?, ?, ?, ?);', [title, date.strftime('%d-%m-%Y'), author, text, link[0], date.today().strftime('%Y-%m-%d')])
					conn.commit()
	print('Successfully processed date: ', start.date())
	start += step
conn.close()
