# VECERNJI LIST
# Croatia
import requests
from lxml import html
import sqlite3
from datetime import date
import sys
from newspaper import Article
conn = sqlite3.connect(sys.argv[1])
c = conn.cursor()
# e.g. https://www.vecernji.hr/hrvatska/excluded-more?page=
url = sys.argv[2]
page = int(sys.argv[3])

prefix = 'https://www.vecernji.hr'

while True:
	print('Started processing page: ' + str(page))
	r = requests.get(url + str(page))
	p = html.fromstring(r.text)
	# START: mine for links
	# on every column page with links to articles mine for the very links (xpath code of a link)
	t = p.xpath('//a[@class="card__link"]/@href')
	# STOP: mine for links
	for l in t:
		a = Article(prefix + l)
		a.download()
		a.parse()
		# default variables: a.title, a.publish_date, a.authors, a.text
		# if some don't work, mine for them in code
		# START: mine for date, authors
		r3 = requests.get(prefix + l)
		p3 = html.fromstring(r3.text)
		publish_date = p3.xpath('//meta[@itemprop="datePublished"]/@content')
		if len(publish_date) > 0:
			publish_date = publish_date[0]
		else:	
			publish_date = ''
		author = p3.xpath('//a[@class="article__author--link"]/text()')
		if len(author) > 0:
			author = author[0]
		else:
			author = ''
		# STOP: mine for date, authors
		q1 = c.execute('select count(*) from articles where title = ?;', [a.title])
		r1 = q1.fetchone()
		exists = r1[0]
		if exists == 0:
			q2 = c.execute('insert into articles values(Null, ?, ?, ?, ?, ?, ?);', [a.title, publish_date, author, a.text, l, date.today().strftime('%Y-%m-%d')])
			conn.commit()
	print('Successfully processed page: ', page)
	page = page + 1
