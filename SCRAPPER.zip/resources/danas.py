# DANAS
# Serbia
import requests
from lxml import html
from newspaper import Article
import sys
import sqlite3
from datetime import date
conn = sqlite3.connect(sys.argv[1])
c = conn.cursor()
url = sys.argv[2]
page = int(sys.argv[3])

while True:
	print('Started processing page: ' + str(page))
	r = requests.get(url + str(page))
	p = html.fromstring(r.text)
	# START: mine for links
	# on every column page with links to articles mine for the very links (xpath code of a link)
	t = p.xpath('//h2[@class="article-post-title"]/a/@href')
	# STOP: mine for links
	for l in t:
		a = Article(l)
		a.download()
		a.parse()
		# default variables: a.title, a.publish_date, a.authors, a.text
		# if some don't work, mine for them in code
		# START: mine for authors
		r1 = requests.get(l)
		p1 = html.fromstring(r.text)
		authors = p1.xpath('//span[@class="post-meta author vcard"]/text()')
		if len(authors) > 0:
			authors = authors[0].split(':  ')
			if len(authors) >= 1:
				authors = authors[1]
			else:
				authors = authors[0]
		else:
			authors = ''
		# STOP: mine for authors
		q1 = c.execute('select count(*) from articles where title = ?;', [a.title])
		if q1.fetchone()[0] == 0:
			q2 = c.execute('insert into articles values(Null, ?, ?, ?, ?, ?, ?);', [a.title, a.publish_date.strftime('%Y-%m-%d'), authors, a.text, l, date.today().strftime('%Y-%m-%d')])
			conn.commit()
	print('Successfully processed page: ' + str(page))
	page = page + 1
